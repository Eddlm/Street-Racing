﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GTA;
using GTA.Native;
using GTA.Math;
using System.Drawing;
using System.Globalization;
using System.Xml;
using System.IO;
using NativeUI;

namespace Street_Races
{
    class Util
    {

        public static void WarnPlayer(string script_name, string title, string message)
        {
            Function.Call(Hash._SET_NOTIFICATION_TEXT_ENTRY, "STRING");
            Function.Call(Hash._ADD_TEXT_COMPONENT_STRING, message);
            Function.Call(Hash._SET_NOTIFICATION_MESSAGE, "CHAR_SOCIAL_CLUB", "CHAR_SOCIAL_CLUB", true, 0, title, "~b~" + script_name);
        }

        public enum Subtask
        {
            AIMED_SHOOTING_ON_FOOT = 4,
            GETTING_UP = 16,
            MOVING_ON_FOOT_NO_COMBAT = 35,
            MOVING_ON_FOOT_COMBAT = 38,
            USING_STAIRS = 47,
            CLIMBING = 50,
            GETTING_OFF_SOMETHING = 51,
            SWAPPING_WEAPON = 56,
            REMOVING_HELMET = 92,
            DEAD = 97,
            MELEE_COMBAT = 130,
            HITTING_MELEE = 130,
            SITTING_IN_VEHICLE = 150,
            DRIVING_WANDERING = 151,
            EXITING_VEHICLE = 152,

            ENTERING_VEHICLE_GENERAL = 160,
            ENTERING_VEHICLE_BREAKING_WINDOW = 161,
            ENTERING_VEHICLE_OPENING_DOOR = 162,
            ENTERING_VEHICLE_ENTERING = 163,
            ENTERING_VEHICLE_CLOSING_DOOR = 164,

            EXIING_VEHICLE_OPENING_DOOR_EXITING = 167,
            EXITING_VEHICLE_CLOSING_DOOR = 168,
            DRIVING_GOING_TO_DESTINATION_OR_ESCORTING = 169,
            USING_MOUNTED_WEAPON = 199,
            AIMING_THROWABLE = 289,
            AIMING_GUN = 290,
            AIMING_PREVENTED_BY_OBSTACLE = 299,
            IN_COVER_GENERAL = 287,
            IN_COVER_FULLY_IN_COVER = 288,

            RELOADING = 298,

            RUNNING_TO_COVER = 300,
            IN_COVER_TRANSITION_TO_AIMING_FROM_COVER = 302,
            IN_COVER_TRANSITION_FROM_AIMING_FROM_COVER = 303,
            IN_COVER_BLIND_FIRE = 304,

            PARACHUTING = 334,
            PUTTING_OFF_PARACHUTE = 336,

            JUMPING_OR_CLIMBING_GENERAL = 420,
            JUMPING_AIR = 421,
            JUMPING_FINISHING_JUMP = 422,
        }

        public static bool IsSubttaskActive(Ped ped, Subtask task)
        {
            return Function.Call<bool>(Hash.GET_IS_TASK_ACTIVE, ped, (int)task);
        }
        public static bool IsDriving(Ped ped)
        {
            return (Util.IsSubttaskActive(ped, Util.Subtask.DRIVING_WANDERING) || Util.IsSubttaskActive(ped, Util.Subtask.DRIVING_GOING_TO_DESTINATION_OR_ESCORTING));
        }

        public static int GetRandomInt(int min, int max)
        {
            Random rnd = new Random();
            return rnd.Next(min, max);
        }
        public static void DisplayHelpTextThisFrame(string text)
        {
            Function.Call(Hash._SET_TEXT_COMPONENT_FORMAT, "STRING");
            Function.Call(Hash._ADD_TEXT_COMPONENT_STRING, text);
            Function.Call(Hash._DISPLAY_HELP_TEXT_FROM_STRING_LABEL, 0, false, true, -1);
        }


        public static bool IsPotentiallySliding(Vehicle veh, float threshold)
        {
            return Math.Abs(Function.Call<Vector3>(Hash.GET_ENTITY_ROTATION_VELOCITY, veh, true).Z) > threshold;
        }
        public static bool IsSliding(Vehicle veh, float threshold)
        {
            return Math.Abs(Function.Call<Vector3>(Hash.GET_ENTITY_SPEED_VECTOR, veh, true).X) > threshold;
        }
        public static int GetBoneIndex(Entity entity, string value)
        {
            return GTA.Native.Function.Call<int>(Hash._0xFB71170B7E76ACBA, entity, value);
        }
        public static Vector3 GetBoneCoords(Entity entity, int boneIndex)
        {
            return GTA.Native.Function.Call<Vector3>(Hash._0x44A8FCB8ED227738, entity, boneIndex);
        }
        public static List<string> Exhausts = new List<string>
    {
        "exhaust","exhaust_2","exhaust_3","exhaust_4","exhaust_5","exhaust_6","exhaust_7"
    };

        public static void ForceNitro(Vehicle veh)
        {
            if (CanWeUse(veh))
            {
                Function.Call(Hash._SET_VEHICLE_ENGINE_TORQUE_MULTIPLIER, veh, 30f);

                if (Function.Call<bool>(Hash._0x8702416E512EC454, "scr_carsteal4"))
                {
                    float direction = veh.Heading;
                    float pitch = Function.Call<float>(Hash.GET_ENTITY_PITCH, veh);

                    foreach (string exhaust in Exhausts)
                    {
                        Vector3 offset = GetBoneCoords(veh, GetBoneIndex(veh, exhaust));
                        Function.Call(Hash._0x6C38AF3693A69A91, "scr_carsteal4");
                        Function.Call<int>(Hash.START_PARTICLE_FX_NON_LOOPED_AT_COORD, "scr_carsteal5_car_muzzle_flash", offset.X, offset.Y, offset.Z, 0f, pitch, direction - 90f, 1.0f, false, false, false);
                    }
                }
                else
                {
                    Function.Call(Hash._0xB80D8756B4668AB6, "scr_carsteal4");
                }
            }
        }

        public static void HandleAISpinoutHelp(Vehicle veh)
        {
            if (CanWeUse(veh) && veh.IsOnAllWheels)
            {
                Util.HandleAISuddenSteering(veh);
                if (Util.ForwardSpeed(veh) > 10f && Util.IsSliding(veh,6f))
                {
                    if (!Util.IsPotentiallySliding(veh,1.5f))
                    {
                        if (Function.Call<Vector3>(Hash.GET_ENTITY_SPEED_VECTOR, veh, true).X > 1f && veh.SteeringAngle<0)
                        {
                            if (StreetRaces.Debug) World.DrawMarker(MarkerType.UpsideDownCone, veh.Position + (veh.ForwardVector * -2) + veh.RightVector, new Vector3(0, 0, 0), new Vector3(0, 0, 0), new Vector3(1, 1, 1), Color.Blue);
                            Function.Call(Hash.APPLY_FORCE_TO_ENTITY, veh, 3, 0.1f, 0f, 0f, 0f, 2f, -0.2f, 0, true, true, true, true, true);
                        }
                        else
                        if (Function.Call<Vector3>(Hash.GET_ENTITY_SPEED_VECTOR, veh, true).X < -1f && veh.SteeringAngle > 0)
                        {
                            if (StreetRaces.Debug) World.DrawMarker(MarkerType.UpsideDownCone, veh.Position + (veh.ForwardVector * -2) - veh.RightVector, new Vector3(0, 0, 0), new Vector3(0, 0, 0), new Vector3(1, 1, 1), Color.Blue);
                            Function.Call(Hash.APPLY_FORCE_TO_ENTITY, veh, 3, -0.1f, 0f, 0f, 0f, 2f, -0.2f, 0, true, true, true, true, true);
                        }
                    }
                    /*if (StreetRaces.Debug)*/

                }
            }

        }
        public static bool CanWeUse(Entity entity)
        {
            return entity != null && entity.Exists();
        }

        public static bool IsPlayerParticipating()
        {
            if (StreetRaces.Racers.Count > 0 && StreetRaces.Racers[StreetRaces.Racers.Count - 1].driver.IsPlayer) return true;
            return false;
        }
        public static void HandleAICatchUp(Vehicle veh)
        {
            if (veh.IsOnAllWheels)
            {
                if (ForwardSpeed(veh) < 30f)
                {
                    //Steering cheat
                    if(!IsPotentiallySliding(veh, 2f)) Function.Call(Hash.APPLY_FORCE_TO_ENTITY, veh, 3, veh.SteeringAngle * -0.001f, 0f, 0f, 0f, 0.5f, 0f, 0, true, true, true, true, true);

                    //Acceleration cheat
                    if (Math.Abs(veh.SteeringAngle) < 30 && veh.Acceleration > 0) Function.Call(Hash.APPLY_FORCE_TO_ENTITY, veh, 3, 0f, 1f, 0f, 0f, 0f, 0f, 0, true, true, true, true, true);

                }
                if(ForwardSpeed(veh)>15)
                {
                    //Brake cheat
                    if (!IsSliding(veh, 5f) && veh.Acceleration == 0) Function.Call(Hash.APPLY_FORCE_TO_ENTITY, veh, 3, 0f, -1f, 0f, 0f, 0f, 0f, 0, true, true, true, true, true);
                }

                //Stabilize
                if (Function.Call<Vector3>(Hash.GET_ENTITY_SPEED_VECTOR, veh, true).X > 2f)
                {
                    Function.Call(Hash.APPLY_FORCE_TO_ENTITY, veh, 3, -0.5f, 0f, 0f, 0f, 0f, 0f, 0, true, true, true, true, true);
                }
                else if (Function.Call<Vector3>(Hash.GET_ENTITY_SPEED_VECTOR, veh, true).X < -2f)
                {
                    Function.Call(Hash.APPLY_FORCE_TO_ENTITY, veh, 3, 0.5f, 0f, 0f, 0f, 0f, 0f, 0, true, true, true, true, true);
                }
            }

        }
        public static float CalculateHandicap(Vehicle veh)
        {
            // if (veh.Model.Hash == (int)VehicleHash.SlamVan) return 0.7f;

            return 0.5f;
        }
        public static bool CarCanSeePos(Vehicle veh, Vector3 pos)
        {
            //if (veh.Position.DistanceTo(pos) < 50f) return true;
            if(veh.Position.DistanceTo(pos) < 100f)
            {
                RaycastResult raycast = World.Raycast(veh.Position + new Vector3(0, 0, 3), pos + new Vector3(0, 0, 3), IntersectOptions.Map);
                if (!raycast.DitHitAnything) return true;
            }

            
            return false;
        }

        public static float GetPitch(Vehicle veh)
        {
            return Function.Call<float>(Hash.GET_ENTITY_PITCH, veh);
        }

        public static bool HandleAIOutOfPath(Vehicle veh, bool avoidjumps)
        {
            if (CanWeUse(veh) && veh.IsOnAllWheels && ForwardSpeed(veh) > 20f)
            {
                if (veh.SteeringScale > 0.6) return true;

                    Vector3 RealDirection = veh.Position + (veh.UpVector * -veh.HeightAboveGround) + (veh.Velocity * CalculateHandicap(veh));
                    Vector3 SteeredDirection = RealDirection + (veh.RightVector * -(veh.SteeringAngle / 20));
                    Vector3 SteeredDirectionToGround = SteeredDirection;

                    RaycastResult toground = World.Raycast(SteeredDirection + new Vector3(0, 0, 3), SteeredDirection + new Vector3(0, 0, -3), IntersectOptions.Map);

                    if (toground.HitCoords != Vector3.Zero) SteeredDirectionToGround = toground.HitCoords;

                    if (StreetRaces.Debug) World.DrawMarker(MarkerType.DebugSphere, SteeredDirectionToGround, new Vector3(0, 0, 0), new Vector3(0, 0, 0), new Vector3(0.3f, 0.3f, 0.3f), Color.Yellow);
                    if (StreetRaces.Debug) World.DrawMarker(MarkerType.DebugSphere, SteeredDirection, new Vector3(0, 0, 0), new Vector3(0, 0, 0), new Vector3(0.3f, 0.3f, 0.3f), Color.Green);


                        //DisplayHelpTextThisFrame(raycast.HitCoords.DistanceTo(direction).ToString());

                        //Jumps
                        if (avoidjumps && (SteeredDirection.Z - toground.HitCoords.Z > 0.7f))
                        {
                            if (StreetRaces.Debug) World.DrawMarker(MarkerType.UpsideDownCone, SteeredDirection + new Vector3(0, 0, 1), new Vector3(0, 0, 0), new Vector3(0, 0, 0), new Vector3(2, 2, 2), Color.Black);
                            return true;
                        }

                        //Out of path
                        if (!IsSliding(veh, 2f) && IsPointOnRoad(veh.Position, veh) && !IsPointOnRoad(SteeredDirectionToGround,veh)) // || raycastoutofpath.HitCoords.DistanceTo(posoutofroad)>4f)
                        {
                            if (World.GetNextPositionOnStreet(SteeredDirectionToGround).DistanceTo(SteeredDirectionToGround) > 20f || (SteeredDirection.Z - toground.HitCoords.Z > 2f))
                            {
                                if (StreetRaces.Debug) World.DrawMarker(MarkerType.UpsideDownCone, World.GetNextPositionOnStreet(SteeredDirectionToGround) + new Vector3(0, 0, 1.5f) + new Vector3(0, 0, -0.4f), new Vector3(0, 0, 0), new Vector3(0, 0, 0), new Vector3(1, 1, 1), Color.Red);
                                return true;
                            }
                        }
            }
            return false;
        }

        public static bool HandleAISlamToWall(Vehicle veh)
        {
            if (veh.IsOnAllWheels && ForwardSpeed(veh) >10f && Math.Abs(veh.SteeringAngle) > 30f)
            {
                Vector3 direction = veh.Position + veh.Velocity;
                Vector3 origin = veh.Position + (veh.ForwardVector * (veh.Model.GetDimensions().Y));

                //Walls
                RaycastResult raycastoutofpath = World.Raycast(origin, direction, IntersectOptions.Map);

                if(StreetRaces.Debug) DrawLine(origin,direction);

                Vector3 marker = direction;
                if (raycastoutofpath.DitHitAnything)
                {
                    marker = raycastoutofpath.HitCoords;
                    if (StreetRaces.Debug) World.DrawMarker(MarkerType.DebugSphere, marker, new Vector3(0, 0, 0), new Vector3(0, 0, 0), new Vector3(1f, 1f, 1f), Color.Red);
                    if (raycastoutofpath.HitCoords != Vector3.Zero && raycastoutofpath.HitCoords.DistanceTo(direction) > 2f)
                    {
                        return true;// ForceBrake(veh, 0.5f);
                    }
                }
            }
            return false;
        }

        public static void DrawLine(Vector3 from, Vector3 to)
        {
            Function.Call(Hash.DRAW_LINE, from.X, from.Y, from.Z, to.X, to.Y, to.Z, 255, 255, 0, 255);
        }
        public static void ForceBrake(Vehicle veh) //, float force
        {
            if (CanWeUse(veh) && veh.IsOnAllWheels)
            {
                Ped driver = veh.GetPedOnSeat(VehicleSeat.Driver);
                if (CanWeUse(driver)) driver.DrivingSpeed = veh.Speed * 0.8f;
                /*veh.BrakeLightsOn = true;
                Function.Call(Hash.APPLY_FORCE_TO_ENTITY, veh, 3, 0f, -force, 0f, 0f, 0f, -0.2f, 0, true, true, true, true, true);

                //Stabilize
                if (Function.Call<Vector3>(Hash.GET_ENTITY_SPEED_VECTOR, veh, true).X > 5f)
                {
                    Function.Call(Hash.APPLY_FORCE_TO_ENTITY, veh, 3, 0.5f, 0f, 0f, 0f, 0.3f, -0.2f, 0, true, true, true, true, true);
                }
                else
                if (Function.Call<Vector3>(Hash.GET_ENTITY_SPEED_VECTOR, veh, true).X < -5f)
                {
                    Function.Call(Hash.APPLY_FORCE_TO_ENTITY, veh, 3, -0.5f, 0f, 0f, 0f, 0.3f, -0.2f, 0, true, true, true, true, true);
                }
                */
            }
        }
        public static void HandleAISuddenSteering(Vehicle veh)
        {
            if (veh.IsOnAllWheels && IsPotentiallySliding(veh, 1.5f) && !IsSliding(veh,0.5f) && Function.Call<Vector3>(Hash.GET_ENTITY_SPEED_VECTOR, veh, true).Y > 40f)
            {
                if (StreetRaces.Debug) World.DrawMarker(MarkerType.DebugSphere, veh.Position + new Vector3(0, 0, 3), new Vector3(0, 0, 0), new Vector3(0, 0, 0), new Vector3(1, 1, 1), Color.Orange);
                Function.Call(Hash.APPLY_FORCE_TO_ENTITY, veh, 3, Function.Call<Vector3>(Hash.GET_ENTITY_ROTATION_VELOCITY, veh, true).Z * -0.1f, 0f, 0f, 0f, -5f, 0f, 0, true, true, true, true, true);
            }
        }

        public static bool IsOdd(int value)
        {
            return value % 2 != 0;
        }

        public static Racer GetRacerInFirst()
        {
            foreach (Racer racer in StreetRaces.Racers) if (racer.PositionInRace == 1) return racer;
            return null;
        }
        public static Racer GetPlayerRacer()
        {
            foreach (Racer racer in StreetRaces.Racers) if (racer.driver == Game.Player.Character) return racer;
            return null;
        }
        public static bool HandleAIRearEndHelp(Vehicle veh)
        {
            if (CanWeUse(veh) && veh.IsOnAllWheels && Function.Call<Vector3>(Hash.GET_ENTITY_SPEED_VECTOR, veh, true).Y > 2f)
            {
                RaycastResult ray = World.RaycastCapsule(veh.Position /*+ new Vector3(0, 0, 1f)*/ + (veh.ForwardVector * veh.Model.GetDimensions().Y), (veh.Velocity), 1f, 1f, IntersectOptions.Everything, veh); //(veh.ForwardVector*5
                Entity ent = ray.HitEntity;
                Vector3 hitpos = ray.HitCoords;
                if (CanWeUse(ent) && ent.Model.IsCar)
                {                    
                    if (veh.IsInRangeOf(hitpos, 30f) && (veh.Velocity.Length() - 20f) > ent.Velocity.Length())
                    {
                        if (StreetRaces.Debug) World.DrawMarker(MarkerType.DebugSphere, hitpos, new Vector3(0, 0, 0), new Vector3(0, 0, 0), new Vector3(0.2f, 0.2f, 0.2f), Color.Green);
                        return true;// ForceBrake(veh, 0.5f);

                    }
                    if (veh.IsInRangeOf(hitpos, 15f) && (veh.Velocity.Length() - 10f) > ent.Velocity.Length())
                    {
                        if (StreetRaces.Debug) World.DrawMarker(MarkerType.DebugSphere, hitpos, new Vector3(0, 0, 0), new Vector3(0, 0, 0), new Vector3(0.2f, 0.2f, 0.2f), Color.Yellow);
                        return true;// ForceBrake(veh, 0.5f);

                    }
                    if (veh.IsInRangeOf(hitpos, 10f) && (veh.Velocity.Length() - 2f) > ent.Velocity.Length())
                    {
                        
                        if (StreetRaces.Debug) World.DrawMarker(MarkerType.DebugSphere, hitpos, new Vector3(0, 0, 0), new Vector3(0, 0, 0), new Vector3(0.2f, 0.2f, 0.2f), Color.Orange);
                        return true;//  ForceBrake(veh, 0.5f);
                    }
                    if (veh.IsInRangeOf(hitpos, 5f) && veh.Velocity.Length() > ent.Velocity.Length())
                    {
                        if (StreetRaces.Debug) World.DrawMarker(MarkerType.DebugSphere, hitpos , new Vector3(0, 0, 0), new Vector3(0, 0, 0), new Vector3(0.2f, 0.2f, 0.2f), Color.Red);
                        return true;// ForceBrake(veh, 0.5f);

                    }
                }
            }
            return false;
        }

        public static int CountDownValue = 3;
        public static int CountdownRef = Game.GameTime;
        public static bool Countdown()
        {
            if (CountdownRef < Game.GameTime)
            {
                string Countdown = CountDownValue.ToString();
                if (CountDownValue == 0) Countdown = "GO";
                BigMessageThread.MessageInstance.ShowColoredShard(Countdown, "", HudColor.HUD_COLOUR_BLACK, HudColor.HUD_COLOUR_MENU_YELLOW, 800);
                CountdownRef = Game.GameTime + 1500;

                if (CountDownValue > 0)
                {
                    CountDownValue--;
                    return false;
                }
                else CountDownValue = 3; return true;

            }
            return false;
        }

        public static float ForwardSpeed(Vehicle veh)
        {
            if (CanWeUse(veh)) return Function.Call<Vector3>(Hash.GET_ENTITY_SPEED_VECTOR, veh, true).Y; else return 0;
        }

        public static bool IsRaining()
        {
            int weather = Function.Call<int>(GTA.Native.Hash._0x564B884A05EC45A3); //get current weather hash
            switch (weather)
            {
                case (int)Weather.Blizzard:
                    {
                        return true;
                    }
                case (int)Weather.Clearing:
                    {
                        return true;
                    }
                case (int)Weather.Foggy:
                    {
                        return true;
                    }
                case (int)Weather.Raining:
                    {
                        return true;
                    }
                case (int)Weather.Neutral:
                    {
                        return true;
                    }
                case (int)Weather.ThunderStorm:
                    {
                        return true;
                    }
                case (int)Weather.Snowlight:
                    {
                        return true;
                    }
                case (int)Weather.Snowing:
                    {
                        return true;
                    }
                case (int)Weather.Christmas:
                    {
                        return true;
                    }
            }
            return false;
        }
        public static bool IsNightTime()
        {
            int hour = Function.Call<int>(Hash.GET_CLOCK_HOURS);
            return (hour > 20 || hour < 7);
        }

        public enum Nodetype { AnyRoad, Road, Offroad, Water }
        public static Vector3 GenerateSpawnPos(Vector3 desiredPos, Nodetype roadtype, bool sidewalk)
        {

            Vector3 finalpos = Vector3.Zero;
            bool ForceOffroad = false;


            OutputArgument outArgA = new OutputArgument();
            int NodeNumber = 1;
            int type = 0;

            if (roadtype == Nodetype.AnyRoad) type = 1;
            if (roadtype == Nodetype.Road) type = 0;
            if (roadtype == Nodetype.Offroad) { type = 1; ForceOffroad = true; }
            if (roadtype == Nodetype.Water) type = 3;


            int NodeID = Function.Call<int>(Hash.GET_NTH_CLOSEST_VEHICLE_NODE_ID, desiredPos.X, desiredPos.Y, desiredPos.Z, NodeNumber, type, 300f, 300f);
            if (ForceOffroad)
            {
                while (!Function.Call<bool>(Hash._GET_IS_SLOW_ROAD_FLAG, NodeID) && NodeNumber < 500)
                {
                    NodeNumber++;
                    NodeID = Function.Call<int>(Hash.GET_NTH_CLOSEST_VEHICLE_NODE_ID, desiredPos.X, desiredPos.Y, desiredPos.Z, NodeNumber + 5, type, 300f, 300f);
                }
            }
            Function.Call(Hash.GET_VEHICLE_NODE_POSITION, NodeID, outArgA);
            finalpos = outArgA.GetResult<Vector3>();

            if (sidewalk) finalpos = World.GetNextPositionOnSidewalk(finalpos);
            return finalpos;
        }


        public static bool IsPointOnRoad(Vector3 pos,Entity ent)
        {
            return Function.Call<bool>(Hash.IS_POINT_ON_ROAD, pos.X, pos.Y, pos.Z, ent);
        }
        public static bool IsPointNeaRoad(Vector3 pos)
        {
            return pos.DistanceTo(World.GetNextPositionOnStreet(pos, true)) < 10f;
        }
        public static void SpawnDrivers()
        {
            StreetRaces.MaxRacers = StreetRaces.SetupCarsNumber.IndexToItem(StreetRaces.SetupCarsNumber.Index);
            XmlDocument document = new XmlDocument();
            document.Load(@"scripts\\" + StreetRaces.ScriptFolder + "/Racers/Racers.xml");

            int patienced = 0;
            while (document == null)
            {
                patienced++;
                Script.Wait(0);
                if (patienced > 50)
                {
                    UI.Notify("Coudn't load Racers file.");
                    return;
                }
            }

            XmlElement docroot = document.DocumentElement;
            XmlNodeList nodelist = docroot.SelectNodes("//Racers/*");
            //XmlNodeList nodelist2 = nodelist;
            List<String> drivers = new List<String>();
            List<String> pickeddrivers = new List<String>();

            foreach (XmlElement driver in nodelist)
            {
                if (driver.GetAttribute("Class") == StreetRaces.ClassList[StreetRaces.CarClass.Index].ToString())
                {
                    if (1==1)
                    {
                        drivers.Add(driver.GetAttribute("Name"));
                    }
                }
            }


            if (StreetRaces.MaxRacers > drivers.Count)
            {
                Util.AddNotification("CHAR_SOCIAL_CLUB", "~b~" + StreetRaces.ScriptName, "NOT ENOUGH RACERS", "There's not enough racers installed. Lowering the number of racers to "+drivers.Count+" (all racers found)");
                StreetRaces.MaxRacers = drivers.Count;


            } //UI.Notify("Not enough cars for this Race, lowering limit."); 

            var copyDrivers = new List<string>(drivers);
            for (int _ = 0; _ < StreetRaces.MaxRacers; _++)
            {
                int i = GetRandomInt(0, copyDrivers.Count);
                pickeddrivers.Add(copyDrivers[i]);
                copyDrivers.RemoveAt(i);
            }
            //UI.Notify(pickeddrivers.Count + " Drivers found.");

            Vector3 position = StreetRaces.RaceWaypoints[0];
            int number = -1;
            float back = 0;
            foreach (XmlElement driver in nodelist)
            {
                if (pickeddrivers.Contains(driver.GetAttribute("Name")))
                {
                    number++;
                    //UI.Notify("Spawning " + driver.GetAttribute("Name"));
                    //File.WriteAllText(@"scripts\\DragMeets\debug.txt", driver.GetAttribute("DriverName"));

                    if (StreetRaces.Racers.Count>0)
                    {
                        if (!IsOdd(number)) position = StreetRaces.Racers[0].car.Position + (StreetRaces.Racers[0].car.ForwardVector * - (back)); else position = StreetRaces.Racers[0].car.Position + (StreetRaces.Racers[0].car.ForwardVector * - (back)) + (StreetRaces.Racers[0].car.RightVector * 2);
                    }

                    Vehicle veh = World.CreateVehicle(int.Parse(driver.SelectSingleNode("Vehicle/Model").InnerText), position,StreetRaces.RaceHeading);

                    int patience = 0;
                    while (!CanWeUse(veh))
                    {
                        patience++;
                        DisplayHelpTextThisFrame("Trying to spawn " + driver.SelectSingleNode("Vehicle/Model").InnerText + " for the Race...(" + patience + "/100)");
                        if (patience > 99)
                        {
                            WarnPlayer(StreetRaces.ScriptName + " " + StreetRaces.ScriptVer, "VEHICLE LOAD ERROR", "Error trying to load " + driver.SelectSingleNode("Vehicle/Model").InnerText + ". Aborting Race.");
                            StreetRaces.ShouldForceClean=true;
                            break;
                        }
                        Script.Wait(0);
                    }
                    //File.AppendAllText(@"scripts\\DragMeets\debug.txt", " - " + " created");

                    Ped ped;
                    if (driver.SelectSingleNode("PedModel") == null || driver.SelectSingleNode("PedModel").InnerText == "random")
                    {
                        ped = World.CreatePed("U_M_Y_CYCLIST_01", veh.Position.Around(2f));
                    }
                    else
                    {
                        ped = World.CreatePed(driver.SelectSingleNode("PedModel").InnerText, veh.Position.Around(2f));
                    }
                    while (veh == null || ped == null)
                    {
                        Script.Wait(0);
                    }
                    //File.AppendAllText(@"scripts\\DragMeets\debug.txt", " - " + " ped created");


                    //UI.Notify("Tuning " + driver.GetAttribute("Name"));
                    if (1 == 1)
                    {
                        Function.Call(Hash.SET_VEHICLE_MOD_KIT, veh, 0);

                        if (driver.SelectSingleNode("Vehicle/PrimaryColor") != null) veh.PrimaryColor = (VehicleColor)int.Parse(driver.SelectSingleNode("Vehicle/PrimaryColor").InnerText, CultureInfo.InvariantCulture);
                        else
                        {
                            var color = Enum.GetValues(typeof(VehicleColor));

                            Random random = new Random();
                            veh.PrimaryColor = (VehicleColor)color.GetValue(random.Next(color.Length));

                            Random random2 = new Random();
                            veh.SecondaryColor = (VehicleColor)color.GetValue(random2.Next(color.Length));

                            if (veh.LiveryCount > 0) veh.Livery = GetRandomInt(0, veh.LiveryCount);
                        }



                        if (driver.SelectSingleNode("Vehicle/SecondaryColor") != null) veh.SecondaryColor = (VehicleColor)int.Parse(driver.SelectSingleNode("Vehicle/SecondaryColor").InnerText, CultureInfo.InvariantCulture);
                        if (driver.SelectSingleNode("Vehicle/PearlescentColor") != null) veh.PearlescentColor = (VehicleColor)int.Parse(driver.SelectSingleNode("Vehicle/PearlescentColor").InnerText, CultureInfo.InvariantCulture);
                        if (driver.SelectSingleNode("Vehicle/TrimColor") != null) Function.Call((Hash)0xF40DD601A65F7F19, veh, int.Parse(driver.SelectSingleNode("Vehicle/TrimColor").InnerText, CultureInfo.InvariantCulture));
                        if (driver.SelectSingleNode("Vehicle/DashColor") != null) Function.Call((Hash)0x6089CDF6A57F326C, veh, int.Parse(driver.SelectSingleNode("Vehicle/DashColor").InnerText, CultureInfo.InvariantCulture));
                        if (driver.SelectSingleNode("Vehicle/RimColor") != null) veh.RimColor = (VehicleColor)int.Parse(driver.SelectSingleNode("Vehicle/RimColor").InnerText, CultureInfo.InvariantCulture);

                        if (driver.SelectSingleNode("Vehicle/LicensePlateText") != null) veh.NumberPlate = driver.SelectSingleNode("Vehicle/LicensePlateText").InnerText;
                        if (driver.SelectSingleNode("Vehicle/LicensePlate") != null) Function.Call(Hash.SET_VEHICLE_NUMBER_PLATE_TEXT_INDEX, veh, int.Parse(driver.SelectSingleNode("Vehicle/LicensePlate").InnerText, CultureInfo.InvariantCulture));
                        if (driver.SelectSingleNode("Vehicle/WindowsTint") != null) veh.WindowTint = (VehicleWindowTint)int.Parse(driver.SelectSingleNode("Vehicle/WindowsTint").InnerText, CultureInfo.InvariantCulture);


                        if (driver.SelectSingleNode("Vehicle/WheelType") != null) veh.WheelType = (VehicleWheelType)int.Parse(driver.SelectSingleNode("Vehicle/WheelType").InnerText, CultureInfo.InvariantCulture);

                        if (driver.SelectSingleNode("Vehicle/SmokeColor") != null)
                        {
                            Color color = Color.FromArgb(255, int.Parse(driver.SelectSingleNode("Vehicle/SmokeColor/Color/R").InnerText), int.Parse(driver.SelectSingleNode("Vehicle/SmokeColor/Color/G").InnerText), int.Parse(driver.SelectSingleNode("Vehicle/SmokeColor/Color/B").InnerText));
                            veh.TireSmokeColor = color;
                        }

                        if (driver.SelectSingleNode("Vehicle/NeonColor") != null)
                        {
                            Color color = Color.FromArgb(255, int.Parse(driver.SelectSingleNode("Vehicle/NeonColor/R").InnerText), int.Parse(driver.SelectSingleNode("Vehicle/NeonColor/G").InnerText), int.Parse(driver.SelectSingleNode("Vehicle/NeonColor/B").InnerText));
                            veh.NeonLightsColor = color;
                        }

                        if (driver.SelectSingleNode("Vehicle/Neons/Back") != null) veh.SetNeonLightsOn(VehicleNeonLight.Back, bool.Parse(driver.SelectSingleNode("Vehicle/Neons/Back").InnerText));
                        if (driver.SelectSingleNode("Vehicle/Neons/Front") != null) veh.SetNeonLightsOn(VehicleNeonLight.Front, bool.Parse(driver.SelectSingleNode("Vehicle/Neons/Front").InnerText));
                        if (driver.SelectSingleNode("Vehicle/Neons/Left") != null) veh.SetNeonLightsOn(VehicleNeonLight.Left, bool.Parse(driver.SelectSingleNode("Vehicle/Neons/Left").InnerText));
                        if (driver.SelectSingleNode("Vehicle/Neons/Right") != null) veh.SetNeonLightsOn(VehicleNeonLight.Right, bool.Parse(driver.SelectSingleNode("Vehicle/Neons/Right").InnerText));

                        if(driver.SelectSingleNode("Vehicle/Components") != null)
                        {
                            foreach (XmlElement component in driver.SelectNodes("Vehicle/Components/*"))
                            {
                                int extra = 0;
                                if (int.Parse(component.InnerText, CultureInfo.InvariantCulture) == 0) extra = -1;
                                Function.Call(Hash.SET_VEHICLE_EXTRA, veh, int.Parse(component.GetAttribute("ComponentIndex")), extra);
                            }
                        }
                        if (driver.SelectSingleNode("Vehicle/ModToggles") != null)
                        {
                            foreach (XmlElement component in driver.SelectNodes("Vehicle/ModToggles/*"))
                            {
                                Function.Call(Hash.TOGGLE_VEHICLE_MOD, veh, int.Parse(component.GetAttribute("ToggleIndex")), bool.Parse(component.InnerText));
                            }

                        }

                        if (driver.SelectSingleNode("Vehicle/Mods") != null)
                        {
                            if (driver.SelectSingleNode("Vehicle/CustomTires") != null)
                            {
                                foreach (XmlElement component in driver.SelectNodes("Vehicle/Mods/*"))
                                {
                                    veh.SetMod((VehicleMod)int.Parse(component.GetAttribute("ModIndex")), int.Parse(component.InnerText, CultureInfo.InvariantCulture), bool.Parse(driver.SelectSingleNode("Vehicle/CustomTires").InnerText));
                                }
                            }
                            else
                            {
                                foreach (XmlElement component in driver.SelectNodes("Vehicle/Mods/*"))
                                {
                                    veh.SetMod((VehicleMod)int.Parse(component.GetAttribute("ModIndex")), int.Parse(component.InnerText, CultureInfo.InvariantCulture), false);
                                }
                            }


                        }


                        if (driver.SelectSingleNode("CustomTurbo") != null)
                        {
                            veh.EnginePowerMultiplier = int.Parse(driver.SelectSingleNode("CustomTurbo").InnerText, CultureInfo.InvariantCulture);
                        }

                    }

                    ped.SetIntoVehicle(veh, VehicleSeat.Driver);
                    back += veh.Model.GetDimensions().Y + 0.5f;
                    Script.Wait(500);
                    StreetRaces.Racers.Add(new Racer(veh, ped, driver.GetAttribute("Name")));
                }
            }
            if (CanWeUse(Game.Player.Character.CurrentVehicle))
            {

                //if (!IsOdd(number)) position = StreetRaces.Racers[0].car.Position + (StreetRaces.Racers[0].car.ForwardVector * - (back)); else position = StreetRaces.Racers[0].car.Position + (StreetRaces.Racers[0].car.ForwardVector * - (back)) + (StreetRaces.Racers[0].car.RightVector * 2);

                if (IsOdd(number)) position = StreetRaces.Racers[0].car.Position + (StreetRaces.Racers[0].car.ForwardVector * -(back)); else position = StreetRaces.Racers[0].car.Position + (StreetRaces.Racers[0].car.ForwardVector * -(back)) + (StreetRaces.Racers[0].car.RightVector * 2);

                Game.Player.Character.CurrentVehicle.Position = position;
                Game.Player.Character.CurrentVehicle.Heading = StreetRaces.RaceHeading;
                StreetRaces.Racers.Add(new Racer(Game.Player.Character.CurrentVehicle, Game.Player.Character, Game.Player.Name));
            }
            else
            {
               if(CanWeUse(StreetRaces.Heli)) Game.Player.Character.SetIntoVehicle(StreetRaces.Heli, VehicleSeat.Passenger);
            }
        }
        public static void FlareUpNextCheckpoint(Vector3 pos)
        {
            int flare = Game.GenerateHash("WEAPON_FLAREGUN");

            if (!Function.Call<bool>(Hash.HAS_WEAPON_ASSET_LOADED, flare))
            {
                Function.Call(Hash.REQUEST_WEAPON_ASSET, flare);
                //while (!Function.Call<bool>(Hash.HAS_WEAPON_ASSET_LOADED, flare)) Script.Wait(0);
            }
            else
            {
                if (!Function.Call<bool>(Hash.IS_PROJECTILE_IN_AREA, pos.X - 5, pos.Y - 5, pos.Z - 5, pos.X + 5, pos.Y + 5, pos.Z + 5, true))
                {
                    Function.Call(Hash.SHOOT_SINGLE_BULLET_BETWEEN_COORDS, pos.X, pos.Y, pos.Z+10f, pos.X, pos.Y, pos.Z,5, true, flare, Game.Player.Character, false, false, 200f);
                    //UI.Notify("Shot flare at "+pos.ToString()+"| Distance: "+pos.DistanceTo(Game.Player.Character.Position));
                }
            }

        }

        static T RandomEnumValue<T>()
        {
            var v = Enum.GetValues(typeof(T));
            return (T)v.GetValue(new Random().Next(v.Length));
        }


    //Notification Queues

    public static List<String> MessageQueue = new List<String>();
        public static int MessageQueueInterval = 8000;
        public static int MessageQueueReferenceTime = 0;
        public static void HandleMessages()
        {
            if (MessageQueue.Count > 0)
            {
                DisplayHelpTextThisFrame(MessageQueue[0]);
            }
            else
            {
                MessageQueueReferenceTime = Game.GameTime;
            }
            if (Game.GameTime > MessageQueueReferenceTime + MessageQueueInterval)
            {
                if (MessageQueue.Count > 0)
                {
                    MessageQueue.RemoveAt(0);
                }
                MessageQueueReferenceTime = Game.GameTime;
            }
        }
        public static void AddQueuedHelpText(string text)
        {
            if (!MessageQueue.Contains(text)) MessageQueue.Add(text);
        }

        public static void ClearAllHelpText(string text)
        {
            MessageQueue.Clear();
        }


        public static List<String> NotificationQueueText = new List<String>();
        public static List<String> NotificationQueueAvatar = new List<String>();
        public static List<String> NotificationQueueAuthor = new List<String>();
        public static List<String> NotificationQueueTitle = new List<String>();

        public static int NotificationQueueInterval = 8000;
        public static int NotificationQueueReferenceTime = 0;
        public static void HandleNotifications()
        {
            if (Game.GameTime > NotificationQueueReferenceTime)
            {

                if (NotificationQueueAvatar.Count > 0 && NotificationQueueText.Count > 0 && NotificationQueueAuthor.Count > 0 && NotificationQueueTitle.Count > 0)
                {
                    NotificationQueueReferenceTime = Game.GameTime + ((NotificationQueueText[0].Length / 10) * 1000);
                    Notify(NotificationQueueAvatar[0], NotificationQueueAuthor[0], NotificationQueueTitle[0], NotificationQueueText[0]);
                    NotificationQueueText.RemoveAt(0);
                    NotificationQueueAvatar.RemoveAt(0);
                    NotificationQueueAuthor.RemoveAt(0);
                    NotificationQueueTitle.RemoveAt(0);
                }
            }
        }

        public static void AddNotification(string avatar, string author, string title, string text)
        {
            NotificationQueueText.Add(text);
            NotificationQueueAvatar.Add(avatar);
            NotificationQueueAuthor.Add(author);
            NotificationQueueTitle.Add(title);
        }
        public static void CleanNotifications()
        {
            NotificationQueueText.Clear();
            NotificationQueueAvatar.Clear();
            NotificationQueueAuthor.Clear();
            NotificationQueueTitle.Clear();
            NotificationQueueReferenceTime = Game.GameTime;
            Function.Call(Hash._REMOVE_NOTIFICATION, CurrentNotification);
        }

        public static int CurrentNotification;
        public static void Notify(string avatar, string author, string title, string message)
        {
            if (avatar != "" && author != "" && title != "")
            {
                Function.Call(Hash._SET_NOTIFICATION_TEXT_ENTRY, "STRING");
                Function.Call(Hash._ADD_TEXT_COMPONENT_STRING, message);
                CurrentNotification = Function.Call<int>(Hash._SET_NOTIFICATION_MESSAGE, avatar, avatar, true, 0, title, author);
            }
            else
            {
                UI.Notify(message);
            }
        }

    }

}
