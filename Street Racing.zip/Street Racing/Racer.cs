﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GTA;
using GTA.Native;
using System.IO;
using System.Windows.Forms;
using GTA.Math;
using NativeUI;
using System.Drawing;

namespace Street_Races
{
    public enum NitroUse
    {
        Safe,
        Normal,
        Aggresive,
    }

    public class Racer
    {
        public Vehicle car;
        public Ped driver;

        //Waypoint & Position
        public int CurrentWaypoint = 0;
        public float DistanceToWaypoint = 0;
        public int PositionInRace = 1; //Handled by StreetRacing.HandlePositions();
        public int CurrentLap = 0;
        public int CurrentCheckpoint = 0;
        public string Name = "Racer";
        public int StuckTimer = 0;
        public float MaxSpeed = 120f;
        //Personality
        NitroUse NitroUse = NitroUse.Normal;

        bool OutOfRace = false;

        //Nitro
        float NitroBar = 100;
        int NitroSafety = 0;
        int IntervalBetweenNitros = 2000;

        int NitroTimeLimit = Game.GameTime;


        //AI Safety
        int BrakeTime = 0;

        public Racer(Vehicle model, Ped racer, string name)
        {
            if (Util.CanWeUse(racer))
            {
                Name = name;
                car = racer.CurrentVehicle;
                driver = racer;
                driver.SetIntoVehicle(car, VehicleSeat.Driver);

                if (!driver.IsPlayer)
                {
                    Function.Call(GTA.Native.Hash.SET_DRIVER_ABILITY, driver, 100.0);
                    Function.Call(GTA.Native.Hash.SET_DRIVER_AGGRESSIVENESS, driver, 0);
                    driver.AlwaysKeepTask = true;
                    driver.BlockPermanentEvents = true;

                    Blip blip = car.AddBlip();
                    blip.Color = BlipColor.Blue;

                    Function.Call(GTA.Native.Hash._0x0DC7CABAB1E9B67E, driver, true); //Load Collision
                    Function.Call(GTA.Native.Hash._0x0DC7CABAB1E9B67E, car, true); //Load Collision

                    car.EngineRunning = true;
                }

            }
        }



        public void ProcessRace()
        {

            switch (StreetRaces.RaceStatus)
            {
                case RacePhase.NotRacing:
                    {

                        break;
                    }
                case RacePhase.RaceSetup:
                    {

                        break;
                    }
                case RacePhase.RaceCountDown:
                    {
                        if (!driver.IsPlayer && car.IsConvertible)
                        {
                            if (Util.IsRaining() && car.RoofState == VehicleRoofState.Opened) car.RoofState = VehicleRoofState.Closing;
                            else if (car.RoofState == VehicleRoofState.Closed) car.RoofState = VehicleRoofState.Opening;
                        }
                        break;
                    }
                case RacePhase.RaceInProgress:
                    {
                        if (!OutOfRace) HandleStuck();
                        HandleRacing();
                        break;
                    }

            }
        }
        public void Delete()
        {
            if (!driver.IsPlayer)
            {
                if (car.CurrentBlip != null) car.CurrentBlip.Remove();
                driver.MarkAsNoLongerNeeded();
                car.MarkAsNoLongerNeeded();
            }
        }
        public void HandleStuck()
        {
            if (car.Speed < 3f)
            {
                if (StuckTimer < 500) StuckTimer++; else if (!car.IsOnScreen && car.Position.DistanceTo(Game.Player.Character.Position) > 50) { car.Position = World.GetNextPositionOnStreet(car.Position); car.PlaceOnGround(); }
            }
            else
            {
                if (StuckTimer > 0) StuckTimer = 0;
            }

        }

        public void HandleRacing()
        {
            //Debug notifications
            bool shouldnotify = false;
            if (StreetRaces.Debug && car.IsNearEntity(Game.Player.Character, new Vector3(30, 30, 30))) shouldnotify = true;

            string notification = "Lap: " + CurrentLap + "/" + StreetRaces.Laps + " | Waypoint: " + CurrentWaypoint;

            if (!driver.IsPlayer)
            {


                //AI Helpers
                if (BrakeTime < Game.GameTime)
                {
                    BrakeTime = Game.GameTime;
                    if (StreetRaces.AICurvePathing.Checked && Util.HandleAIOutOfPath(car, PositionInRace>2)) BrakeTime += 500;
                    if (StreetRaces.AIRearEnd.Checked && Util.HandleAIRearEndHelp(car)) BrakeTime += 100;

                    if (StreetRaces.AISlamToWall.Checked && Util.HandleAISlamToWall(car)) BrakeTime += 500;
                    if (StreetRaces.AISpinout.Checked)
                    {
                        if (Util.IsSliding(car, 10f) && Util.IsPointOnRoad(car.Position, car) && Util.ForwardSpeed(car) > 20) BrakeTime += 500;
                        Util.HandleAISpinoutHelp(car);
                    }
                    if (car.Speed > 20 && Math.Abs(car.SteeringScale) > 0.8f) BrakeTime += 600;
                }

                if (Game.GameTime < BrakeTime)
                {
                    World.DrawMarker(MarkerType.UpsideDownCone, car.Position + new Vector3(0, 0, 1), new Vector3(0, 0, 0), new Vector3(0, 0, 0), new Vector3(2, 2, 2), Color.Red);
                    Util.ForceBrake(car);
                    car.BrakeLightsOn = true;
                }
                else driver.DrivingSpeed = MaxSpeed;


                Vector3 playerpos = Game.Player.Character.Position;
                if (!driver.IsPlayer && !car.IsOnScreen && Util.IsPlayerParticipating() && PositionInRace > 1 && Function.Call<Vector3>(Hash.GET_OFFSET_FROM_ENTITY_GIVEN_WORLD_COORDS, driver, playerpos.X, playerpos.Y, playerpos.Z).Y > 20f) // 
                {
                    if (!car.IsInvincible) car.IsInvincible = true;
                    Util.HandleAICatchUp(car);
                }
                else if (car.IsInvincible) car.IsInvincible = false;

                //Vehicle stuck handler
                if (car.IsUpsideDown && car.IsStopped) car.PlaceOnGround();


                if (StreetRaces.UseNitro.Checked)
                {
                    if (NitroTimeLimit > Game.GameTime)
                    {
                        //Calculate safety when nitroing
                        if (Util.IsSliding(car, 1f) || Util.IsPotentiallySliding(car, 1f) || Math.Abs(car.SteeringAngle) > 30)
                        {
                            if (NitroSafety > 40) NitroSafety = NitroSafety - 5;
                        }

                        if (car.Acceleration == 0 && NitroSafety > 30) NitroSafety = 30;
                    }
                    else
                    {
                        //Calculate safety when not nitroing
                        if (Util.IsSliding(car, 0.2f) || Util.IsPotentiallySliding(car, 0.3f))
                        {
                            if (NitroSafety > 40) NitroSafety = NitroSafety - 5;
                        }
                        else if (NitroSafety < 100)
                        {
                            if (car.CurrentGear < 4) NitroSafety = NitroSafety + 2;
                            else NitroSafety++;
                        }
                    }

                    //dev info
                    if (shouldnotify)
                    {
                        notification = notification + "~n~Nitro bar: " + NitroBar + "%";
                        string safety = "~r~" + NitroSafety + "%";
                        if (NitroSafety > 10) safety = "~y~" + NitroSafety + "%";
                        if (NitroSafety > 50) safety = "~g~" + NitroSafety + "%";
                        notification = notification + "~n~Nitro Safety: " + safety + "~w~";
                    }


                    //General Nitro cancel conditions
                    if (NitroBar < 0 || Util.IsSliding(car, 2f) || Util.IsPotentiallySliding(car, 1f)) NitroTimeLimit = Game.GameTime;


                    //Apply the nitro
                    if (NitroTimeLimit > Game.GameTime && car.CurrentGear > 1 && car.Acceleration > 0 && NitroBar > 0)
                    {
                        notification = notification + "~n~Nitroing";
                        Util.ForceNitro(car);
                        NitroBar--;
                    }//Nitro bar recharge
                    else if (NitroBar < 100) NitroBar = NitroBar + 0.2f;

                    //Generate next nitro session
                    if (NitroSafety > 50 && NitroTimeLimit + IntervalBetweenNitros < Game.GameTime) NitroTimeLimit = Game.GameTime + (Util.GetRandomInt(5, 10) * 1000);
                }
                else shouldnotify = false;

            }


            //Waypoint following
            if (driver.IsAlive && driver.IsInVehicle(car))
            {
                if (StreetRaces.RaceWaypoints.Count > 0 && CurrentLap <= StreetRaces.Laps)
                {
                    if ((!driver.IsPlayer && !Util.IsDriving(driver)) || (driver.IsPlayer && driver.Position.DistanceTo(StreetRaces.RaceWaypoints[CurrentWaypoint]) < 20f))
                    {
                        int DrivingStyle = 4 + 8 + 512 + 262144;
                        //float speed = 120f;
                        if (driver.IsPlayer) StreetRaces.RaceWaypointBlips[CurrentCheckpoint].Scale = 0.7f;

                        CurrentCheckpoint++;
                        if (CurrentWaypoint == StreetRaces.RaceWaypoints.Count - 1)
                        {
                            CurrentWaypoint = 0;
                            if (!driver.IsPlayer)
                            {
                                Vector3 pos = StreetRaces.RaceWaypoints[CurrentWaypoint];
                                //driver.Task.DriveTo(car, pos, 15f, speed, DrivingStyle);
                                //Function.Call(Hash.TASK_VEHICLE_DRIVE_TO_COORD_LONGRANGE, driver, car, pos.X, pos.Y, pos.Z, speed, DrivingStyle, 15f);
                                Function.Call(Hash.TASK_VEHICLE_DRIVE_TO_COORD, driver, car, pos.X, pos.Y, pos.Z, MaxSpeed, 0, car.Model.Hash, DrivingStyle, 14f, 15f);
                            }
                            else
                            {
                                StreetRaces.RaceWaypointBlips[CurrentWaypoint].Scale = 1f;
                                StreetRaces.RaceWaypointBlips[StreetRaces.RaceWaypointBlips.Count - 1].Scale = 0.7f;
                            }
                        }
                        else
                        {
                            if ((driver.Position.DistanceTo(StreetRaces.RaceWaypoints[CurrentWaypoint]) < 20f || (CurrentLap == 0 && CurrentWaypoint == 0)))
                            {
                                //Add a lap
                                if (CurrentWaypoint == 0)
                                {
                                    CurrentCheckpoint = 0;
                                    CurrentLap++;
                                    if (CurrentLap > StreetRaces.Laps) StreetRaces.Winner = this; else if (driver.IsPlayer && CurrentLap > 1) BigMessageThread.MessageInstance.ShowColoredShard(CurrentLap.ToString(), "", HudColor.HUD_COLOUR_BLACK, HudColor.HUD_COLOUR_MENU_YELLOW, 800);
                                }
                                CurrentWaypoint++;


                                //Check if its offroad
                                if (CurrentWaypoint > 0)
                                {
                                    if (!Util.IsPointOnRoad(StreetRaces.RaceWaypoints[CurrentWaypoint], car) || StreetRaces.RaceDangerousWaypoints.Contains(StreetRaces.RaceWaypoints[CurrentWaypoint - 1])) DrivingStyle = 4 + 8 + 512 + 262144 + 4194304;
                                }

                                if (car.Position.DistanceTo(StreetRaces.RaceWaypoints[CurrentWaypoint]) < 100f)
                                {
                                    if (Util.CarCanSeePos(car, StreetRaces.RaceWaypoints[CurrentWaypoint])) DrivingStyle = 4 + 8 + 512 + 262144 + 16777216;
                                    else DrivingStyle = 4 + 8 + 512 + 262144 + 4194304;
                                }


                                if (Util.ForwardSpeed(car) > 25f && StreetRaces.RaceDangerousWaypoints.Contains(StreetRaces.RaceWaypoints[CurrentWaypoint])) MaxSpeed = car.Speed / 1.5f; else MaxSpeed = 120f;// speed = car.Speed / 1.5f;

                                if (!driver.IsPlayer)
                                {
                                    Vector3 pos = StreetRaces.RaceWaypoints[CurrentWaypoint];
                                    //driver.Task.DriveTo(car, pos, 15f, speed, DrivingStyle);
                                    if (CurrentLap == 1 && CurrentWaypoint < 3 && PositionInRace > 5) DrivingStyle += 1;
                                    Function.Call(Hash.TASK_VEHICLE_DRIVE_TO_COORD, driver, car, pos.X, pos.Y, pos.Z, MaxSpeed, 0, car.Model.Hash, DrivingStyle, 14f, 15f);

                                    //Function.Call(Hash.TASK_VEHICLE_DRIVE_TO_COORD_LONGRANGE, driver, car, pos.X, pos.Y, pos.Z, speed, DrivingStyle, 15f);
                                }
                                else
                                {
                                    StreetRaces.RaceWaypointBlips[CurrentWaypoint].Scale = 1f;
                                    if (CurrentCheckpoint > 0) StreetRaces.RaceWaypointBlips[CurrentWaypoint - 1].Scale = 0.7f;
                                }
                            }
                        }
                        //if(driver.IsPlayer) Util.FlareUpNextCheckpoint(StreetRaces.RaceWaypoints[CurrentWaypoint]);
                    }
                }
            }
            else
            {
                if (!OutOfRace)
                {
                    car.LeftIndicatorLightOn = true;
                    car.RightIndicatorLightOn = true;
                    Util.WarnPlayer(StreetRaces.ScriptName, "RACER OUT", Name + " is out of the race.");
                    OutOfRace = true;
                }

            }
            DistanceToWaypoint = (float)Math.Round(car.Position.DistanceTo(StreetRaces.RaceWaypoints[CurrentWaypoint]));

            if (driver.IsPlayer)
            {
                StreetRaces.RaceWaypointBlips[CurrentCheckpoint].Scale = 1f;
                shouldnotify = false;
            }
            if (shouldnotify) Util.DisplayHelpTextThisFrame(notification); else if (driver.IsPlayer) Util.DisplayHelpTextThisFrame("Lap: " + CurrentLap + "/" + StreetRaces.Laps + " | Waypoint: " + CurrentWaypoint + " | Pos: " + PositionInRace);
        }
    }
}